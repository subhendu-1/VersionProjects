package com.version1.frs.model;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "tbl_airport")
public class Airport {
 
	@Id
	@Column(name = "ACODE")
	private String code;
 
	@Column(name = "ANAME")
	private String name;
 
	@Column(name = "ACITY")
	private String city;
 
	public Airport() {
		super();
	}
 
	public Airport(String code, String name, String city) {
		super();
		this.code = code;
		this.name = name;
		this.city = city;
	}
 
	public String getCode() {
		return code;
	}
 
	public void setCode(String code) {
		this.code = code;
	}
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public String getCity() {
		return city;
	}
 
	public void setCity(String city) {
		this.city = city;
	}
}
