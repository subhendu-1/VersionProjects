package com.version1.frs.repository;
 
import org.springframework.data.repository.CrudRepository;
 
import com.version1.frs.model.User;
 
public interface UserRepository extends CrudRepository<User, Integer>{
 
}

 
