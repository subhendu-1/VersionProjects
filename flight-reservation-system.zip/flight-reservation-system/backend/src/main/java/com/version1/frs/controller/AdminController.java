package com.version1.frs.controller;

public class AdminController {

}
