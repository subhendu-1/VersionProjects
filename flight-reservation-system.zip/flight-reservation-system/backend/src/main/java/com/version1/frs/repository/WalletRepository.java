package com.version1.frs.repository;

public class WalletRepository {

}
