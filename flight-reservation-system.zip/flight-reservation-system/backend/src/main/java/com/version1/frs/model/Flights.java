package com.version1.frs.model;

public class Flights {

}
