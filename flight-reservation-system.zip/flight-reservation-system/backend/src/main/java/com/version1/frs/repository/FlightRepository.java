package com.version1.frs.repository;

public class FlightRepository {

}
